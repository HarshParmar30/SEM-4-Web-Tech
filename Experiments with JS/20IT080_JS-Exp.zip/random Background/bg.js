let n = Math.floor(Math.random() * 100);
document.body.style.backgroundColor = '#' + n;