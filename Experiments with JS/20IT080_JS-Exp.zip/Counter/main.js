let Count = 0;
function count(){
    Count++;
    document.getElementById("cnt").textContent = Count;
}