function do_check() {
    let a, txt = "Number ",
        g = "green",
        r = "red";
    a = prompt("Enter value : ");

    if (a % 2 == 0) {
        document.getElementById('res').textContent = txt + a + " is Even";
        document.getElementById('res').style.color = g;

    } else {
        document.getElementById('res').textContent = txt + a + " is Even";
        document.getElementById('res').style.color = r;
    }

}