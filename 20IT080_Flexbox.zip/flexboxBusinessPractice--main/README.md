# FlexboxBusinessPractice-

Simple practice of a business webpage with flexbox.

## Code Languages

HTML5, CSS.
